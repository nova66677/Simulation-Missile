package enstabretagne.applications.capricorn.expertise;

public interface ILocatable {
	Location position();
}
