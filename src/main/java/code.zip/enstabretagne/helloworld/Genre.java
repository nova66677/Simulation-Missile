package enstabretagne.helloworld;

public enum Genre {
	Homme,
	Femme,
	Autre
}
