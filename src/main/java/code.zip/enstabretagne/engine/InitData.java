package enstabretagne.engine;

public abstract class InitData {
	public final String name;
	public InitData(String name) {
		this.name=name;
	}
}
