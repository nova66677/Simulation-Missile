/*
 * 
 */
package enstabretagne.simulation.basics;

// TODO: Auto-generated Javadoc
/**
 * The Interface IScenarioIdProvider.
 */
public interface IScenarioIdProvider {
	
	/**
	 * Gets the scenario id.
	 *
	 * @return the scenario id
	 */
	ScenarioId getScenarioId();
}
