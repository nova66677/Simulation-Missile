package enstabretagne.graphicobjects;

public interface TacticalObject {
	String name();
}
