/*
 * 
 */
package enstabretagne.base.messages;

// TODO: Auto-generated Javadoc
/**
 * The Class MessagesLogicalTimeDuration.
 */
public class MessagesLogicalTimeDuration {

	/** The Constant LogicalDateIsNotDefined. */
	public static final String LogicalDateIsNotDefined="Utilisation d'une date logique non d�finie ";
	
	/** The Constant DoubleValueTooHigh. */
	public static final String DoubleValueTooHigh="La valeur maximale possible pour une dur�e est de ";
}
