/**
* Classe IOperators.java
*@author Olivier VERRON
*@version 1.0.
*/
package enstabretagne.base.time;

/**
 * The Interface IOperators.
 */
public interface IOperators {
	
}

